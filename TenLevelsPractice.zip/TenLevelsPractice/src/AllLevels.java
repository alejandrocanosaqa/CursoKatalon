
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.Assertions;

public class AllLevels {
	
	private static WebDriver driver;
	private static WebDriverWait wait;
	private static ExpectedConditions EC;
	private By startButton = By.id("start_button");
	private By levelTitle=By.cssSelector("h1");
	private By input = By.id("input");
	private By nextButton = By.id("next");
	private By textBoxLevel3=By.cssSelector("#input");
	private By label=By.tagName("label");
    private By buttonLevel3=By.cssSelector("#next");
    private By button1Level4=By.xpath("//a[contains(text(),'Botón 1')]");
    private By button2Level4=By.xpath("//a[contains(text(),'Botón 2')]");
    private By button3Level4=By.xpath("//a[contains(text(),'Botón 3')]");
    private By button4Level4=By.xpath("//a[contains(text(),'Botón 4')]");
    private By linkLevel5=By.xpath("//a[contains(text(),'Enlace!')]");
    private By HelpLevel6=By.cssSelector("#help");
    private By HiddenLevel6=By.xpath("//input[@id='hidden\"']");
    private By ButtonLevel9=By.xpath("//a[@id='next']");
    private By textBoxLevel9=By.xpath("//input[@id='input']");
    private By Sourcelevel10=By.id("source");
    private By Targetlevel10=By.id("target");
    private By TextFinalPractice= By.xpath("//h1[contains(text(),'¡Enhorabuena! Has llegado al final de la práctica')]");
    private String Felicitacion="La practica se ha realizado correctamente,pongame un 10!";
	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
		
  		WebDriverManager.chromedriver().setup();
  		ArrayList<String> optionsList = new ArrayList<String>();
		ChromeOptions chromeOptions = new ChromeOptions();
		optionsList.add("--start-maximized");
		optionsList.add("--incognito");
		optionsList.add("disable-notifications");
		chromeOptions.addArguments(optionsList);
		chromeOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
  		chromeOptions.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
		
		
		driver = new ChromeDriver(chromeOptions);
		
	}

	@AfterAll
	public static void tearDownAfterClass() throws Exception {
		//Close browser
		driver.quit();
	}

	@BeforeEach
	public void setUp() throws Exception {
	}

	@AfterEach
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws InterruptedException {
		
		//Open URL
		driver.get("http://pruebaselenium.serviciosdetesting.com/");
		driver.manage().window().maximize();
		WebElement levelTitleElement=driver.findElement(levelTitle);
		
		//Level 1
		assertEquals(levelTitleElement.getText(),"Práctica Selenium");
		WebElement startButtonElement=driver.findElement(startButton);
		startButtonElement.click();
		levelTitleElement=driver.findElement(levelTitle);
		assertEquals(levelTitleElement.getText(),"Level 2");
		
		//Useful to debug by waiting some miliseconds
		Thread.sleep(2000);
		
		//Level 2
        WebElement textLevel2=driver.findElement(input);
        textLevel2.sendKeys("selenium");
        WebElement nextButtonElement=driver.findElement(nextButton);
        nextButtonElement.click();
        Thread.sleep(1000);
        
        //level 3
        
        WebElement textLabel=driver.findElement(label);
        WebElement imput3=driver.findElement(textBoxLevel3);
        WebElement button3=driver.findElement(buttonLevel3);
        String Text= textLabel.getText();
        imput3.click();
        imput3.sendKeys(Text);
        button3.click();
        Thread.sleep(1000);
        
        //level 4
        WebElement button1L4=driver.findElement(button1Level4);
        WebElement button2L4=driver.findElement(button2Level4);
        WebElement button3L4=driver.findElement(button3Level4);
        WebElement button4L4=driver.findElement(button4Level4);
        button1L4.click();
        button2L4.click();
        button3L4.click();
        button4L4.click();
        //level 5
        //aparece una vez se hacen click en elementos
        WebElement link=driver.findElement(linkLevel5);
        link.click();
        Thread.sleep(1000);
        
        //level 6
        //esperamos hasta que se ve este elemento
        WebElement elementHidden = driver.findElement(HiddenLevel6); 
        JavascriptExecutor jscriptExecutor = (JavascriptExecutor) driver; 
        //codigo javascript que quieres ejecutar y el elemento donde esta
        jscriptExecutor.executeScript("changePage();", elementHidden); 
        
        //level 7
        //aceptamos la alerta para acceder al siguiente nivel
        driver.switchTo().alert().accept();
        
        //level 8
        //obtenemos el control
        Alert alert= driver.switchTo().alert();
        alert.sendKeys("9");
        alert.accept();
        
        //level 9
        WebElement button9=driver.findElement(ButtonLevel9);
        WebElement TextBox9=driver.findElement(textBoxLevel9);
        String password;
        String parentWindowHandler = driver.getWindowHandle(); // Almacena tu ventana actual
        String subWindowHandler = null;

        Set<String> handles = driver.getWindowHandles(); // Obten todas las ventana abiertas
        java.util.Iterator<String> iterator = handles.iterator();
        while (iterator.hasNext()){
            subWindowHandler = iterator.next();// Cámbiate a la ultima ventana (tu pop-up)
        }
        
        password= driver.switchTo().window(subWindowHandler).findElement(By.id("pass")).getText(); 
        driver.switchTo().window(parentWindowHandler);  // Vuelve a tu ventana principal (si lo necesitas)
        TextBox9.sendKeys(password);
        button9.click();
       
       //level 10   
        Actions action=new Actions(driver);
        WebElement from=driver.findElement(Sourcelevel10);
        WebElement to=driver.findElement(Targetlevel10);
        
        //copiamos el elemento origen en el destino
        action.dragAndDrop(from, to).build().perform();
        
        //Comprobamos que llegamos al final de la practica
         WebElement textFinal=driver.findElement(TextFinalPractice);
        Assertions.assertEquals("¡Enhorabuena! Has llegado al final de la práctica", textFinal.getText(),Felicitacion);
		System.out.println(Felicitacion);
	}

}
